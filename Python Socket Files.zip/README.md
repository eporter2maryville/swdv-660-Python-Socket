# swdv-660-Python-Socket
server and client Python Socket

Run $ python3 server.py &  
in terminal to begin server

Run $ python3 client.py
to test client side

use $ sudo lsof -i:9500
to find port processes to stop if troubleshooting and port is occupied

once processes are found use $ kill xxxx
where xxxx is the process number, to free up the port again